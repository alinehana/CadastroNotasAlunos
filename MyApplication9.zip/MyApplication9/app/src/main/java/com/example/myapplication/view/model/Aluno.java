package com.example.myapplication.view.model;

public class Aluno {

    private String ra;
    private String nome;
    private String disciplina;
    private String bimestre1;
    private String bimestre2;
    private String bimestre3;
    private String bimestre4;
    private float media;

    // Construtor
    public Aluno(String ra, String nome, String disciplina, String bimestre1, String bimestre2, String bimestre3, String bimestre4, float media) {
        this.ra = ra;
        this.nome = nome;
        this.disciplina = disciplina;
        this.bimestre1 = bimestre1;
        this.bimestre2 = bimestre2;
        this.bimestre3 = bimestre3;
        this.bimestre4 = bimestre4;
        this.media = media;
    }

    public Aluno() {

    }

    // Getters e Setters
    public String getRa() {
        return ra;
    }

    public void setRa(String ra) {
        this.ra = ra;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDisciplina() {
        return disciplina;
    }

    public void setDisciplina(String disciplina) {
        this.disciplina = disciplina;
    }

    public String getBimestre1() {
        return bimestre1;
    }

    public void setBimestre1(String bimestre1) {
        this.bimestre1 = bimestre1;
    }

    public String getBimestre2() {
        return bimestre2;
    }

    public void setBimestre2(String bimestre2) {
        this.bimestre2 = bimestre2;
    }

    public String getBimestre3() {
        return bimestre3;
    }

    public void setBimestre3(String bimestre3) {
        this.bimestre3 = bimestre3;
    }

    public String getBimestre4() {
        return bimestre4;
    }

    public void setBimestre4(String bimestre4) {
        this.bimestre4 = bimestre4;
    }

    public float getMedia() {
        return media;
    }

    public void setMedia(float media) {
        this.media = media;
    }

    // Método para calcular a média do aluno
    public void calcularMedia() {
        float somaNotas = 0;
        int numBimestres = 0;

        if (!bimestre1.isEmpty()) {
            somaNotas += Float.parseFloat(bimestre1);
            numBimestres++;
        }
        if (!bimestre2.isEmpty()) {
            somaNotas += Float.parseFloat(bimestre2);
            numBimestres++;
        }
        if (!bimestre3.isEmpty()) {
            somaNotas += Float.parseFloat(bimestre3);
            numBimestres++;
        }
        if (!bimestre4.isEmpty()) {
            somaNotas += Float.parseFloat(bimestre4);
            numBimestres++;
        }

        if (numBimestres > 0) {
            this.media = somaNotas / numBimestres;
        } else {
            this.media = 0;
        }
    }
}
