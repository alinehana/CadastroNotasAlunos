package com.example.myapplication.view.view;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.view.helper.SQLiteDataHelper;

import android.database.Cursor;

public class MediaDisciplinaActivity extends AppCompatActivity {

    private TextView tvMediaDisciplina;
    private Button btVoltar;
    private SQLiteDataHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_disciplina);

        // Inicializando os componentes
        tvMediaDisciplina = findViewById(R.id.tvMediaDisciplina);

        dbHelper = new SQLiteDataHelper(this);

        // Calculando a média das notas por disciplina
        calcularMediaDisciplina();

        // Listener para o botão de voltar
        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Volta para a MainActivity
                Intent intent = new Intent(MediaDisciplinaActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }

    @SuppressLint({"Range", "SetTextI18n"})
    private void calcularMediaDisciplina() {
        // Supondo que você tenha a disciplina "Banco de Dados" ou "Programação"
        // Vamos calcular a média das notas para uma disciplina específica
        String disciplinaSelecionada = "Banco de Dados";  // Exemplo: Banco de Dados ou Programação
        float somaNotas = 0;
        int totalNotas = 0;

        // Consultando as notas no banco
        Cursor cursor = dbHelper.getReadableDatabase().rawQuery(
                "SELECT nota FROM notas WHERE disciplina = ?",
                new String[]{disciplinaSelecionada});

        // Somando as notas
        while (cursor.moveToNext()) {
            somaNotas += cursor.getFloat(cursor.getColumnIndex("nota"));
            totalNotas++;
        }

        cursor.close();

        // Calculando a média
        if (totalNotas > 0) {
            float media = somaNotas / totalNotas;
            tvMediaDisciplina.setText("Média de " + disciplinaSelecionada + ": " + media);
        } else {
            Toast.makeText(this, "Não há notas registradas para a disciplina", Toast.LENGTH_SHORT).show();
            tvMediaDisciplina.setText("Sem notas registradas.");
        }
    }
}
