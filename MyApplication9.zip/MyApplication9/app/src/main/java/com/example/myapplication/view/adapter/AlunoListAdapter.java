package com.example.myapplication.view.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.view.model.Aluno;

import java.util.ArrayList;

public class AlunoListAdapter extends RecyclerView.Adapter<AlunoListAdapter.ViewHolder> {

    private ArrayList<Aluno> listaAlunos;
    private Context context;

    /**
     * Construtor
     * @param listaAlunos: lista de alunos retornados do banco
     * @param context
     */
    public AlunoListAdapter(ArrayList<Aluno> listaAlunos, Context context) {
        this.listaAlunos = listaAlunos;
        this.context = context;
    }

    /**
     * Método responsável por carregar o arquivo xml do layout para
     * cada elemento da lista
     */
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        // Corrigir o nome do layout para "activity_notas_aluno"
        View itemList = inflater.inflate(R.layout.activity_notas_aluno, parent, false);

        return new ViewHolder(itemList);
    }

    /**
     * Método que adiciona os dados do Aluno na tela
     */
    @SuppressLint("DefaultLocale")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Aluno aluno = listaAlunos.get(position);
        holder.tvRa.setText(String.valueOf(aluno.getRa()));
        holder.tvNome.setText(aluno.getNome());
        holder.tvDisciplina.setText(aluno.getDisciplina());
        holder.tvMedia.setText(String.format("Média: %.2f", aluno.getMedia()));
    }

    /**
     * Determina a quantidade de elementos na lista
     * @return
     */
    @Override
    public int getItemCount() {
        return this.listaAlunos.size();
    }

    /**
     * ViewHolder para armazenar as views de cada item da lista
     */
    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvRa;
        TextView tvNome;
        TextView tvDisciplina;
        TextView tvMedia;

        public ViewHolder(View itemView) {
            super(itemView);
            // Inicializando os TextViews de acordo com os IDs do layout
            tvRa = itemView.findViewById(R.id.tvRa);            // ID para RA
            tvNome = itemView.findViewById(R.id.tvNome);        // ID para Nome
            tvDisciplina = itemView.findViewById(R.id.tvDisciplina);  // ID para Disciplina
            tvMedia = itemView.findViewById(R.id.tvMedia);      // ID para Média
        }
    }
}
