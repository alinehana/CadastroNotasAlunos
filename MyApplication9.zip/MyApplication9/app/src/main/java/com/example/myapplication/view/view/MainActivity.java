package com.example.myapplication.view.view;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.view.helper.SQLiteDataHelper;

public class MainActivity extends AppCompatActivity {

    private EditText etRa, etNome, etNota;
    private Spinner spDisciplina, spBimestre;

    private SQLiteDataHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os campos do XML
        etRa = findViewById(R.id.etRa);
        etNome = findViewById(R.id.etNome);
        etNota = findViewById(R.id.etNota);
        spDisciplina = findViewById(R.id.spDisciplina);
        spBimestre = findViewById(R.id.spBimestre);
        Button btCadastroNotas = findViewById(R.id.btCadastroNotas);
        Button btNotasAluno = findViewById(R.id.btNotasAluno);
        Button btMediaDisciplina = findViewById(R.id.btMediaDisciplina);

        dbHelper = new SQLiteDataHelper(this);

        // Populando o Spinner de Disciplinas com "Banco de Dados" e "Programação"
        ArrayAdapter<CharSequence> adapterDisciplina = ArrayAdapter.createFromResource(this,
                R.array.disciplinas_array, android.R.layout.simple_spinner_item);
        adapterDisciplina.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spDisciplina.setAdapter(adapterDisciplina);

        // Populando o Spinner de Bimestres com as opções "1", "2", "3" e "4"
        ArrayAdapter<CharSequence> adapterBimestre = ArrayAdapter.createFromResource(this,
                R.array.bimestres_array, android.R.layout.simple_spinner_item);
        adapterBimestre.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBimestre.setAdapter(adapterBimestre);

        // Adicionando o Listener para o botão de Cadastro de Notas
        btCadastroNotas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarNotas();
            }
        });

        // Adicionando o Listener para o botão de Ver Notas por Aluno
        btNotasAluno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentNotasAluno = new Intent(MainActivity.this, NotasAlunoActivity.class);
                startActivity(intentNotasAluno);
            }
        });

        // Adicionando o Listener para o botão de Ver Médias por Disciplina
        btMediaDisciplina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentMediaDisciplina = new Intent(MainActivity.this, MediaDisciplinaActivity.class);
                startActivity(intentMediaDisciplina);
            }
        });
    }

    // Método para cadastrar as notas no banco
    private void cadastrarNotas() {
        String ra = etRa.getText().toString();
        String nome = etNome.getText().toString();
        String notaStr = etNota.getText().toString();
        String disciplina = spDisciplina.getSelectedItem().toString();
        String bimestre = spBimestre.getSelectedItem().toString();

        if (ra.isEmpty() || nome.isEmpty() || notaStr.isEmpty()) {
            Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        float nota = Float.parseFloat(notaStr);
        // Aqui você pode salvar no banco a nota do aluno junto com a disciplina e o bimestre.
        dbHelper.cadastrarNota(ra, nome, disciplina, bimestre, nota);

        Toast.makeText(this, "Nota cadastrada com sucesso!", Toast.LENGTH_SHORT).show();
    }
}
