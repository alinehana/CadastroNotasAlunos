package com.example.myapplication.view.view;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;

public class NotasAlunoActivity extends AppCompatActivity {

    private TextView tvNotasAluno;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas_aluno); // Certifique-se de criar este layout XML

        tvNotasAluno = findViewById(R.id.tvNotasAluno);

        // Aqui você pode configurar o que será exibido na tela de Notas do Aluno
        // Exemplo: exibir as notas ou consultar as informações no banco de dados.
        tvNotasAluno.setText("Notas do Aluno aparecerão aqui.");
    }
}
