package com.example.myapplication.view.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.view.helper.SQLiteDataHelper;
import com.example.myapplication.view.model.Aluno;

import java.util.ArrayList;

public class AlunoDAO {

    private SQLiteDataHelper dbHelper;
    private SQLiteDatabase database;

    public AlunoDAO(Context context) {
        dbHelper = new SQLiteDataHelper(context);
    }

    // Abrir o banco de dados
    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    // Fechar o banco de dados
    public void close() {
        dbHelper.close();
    }

    // Inserir um novo aluno no banco de dados
    public long insert(Aluno aluno) {
        ContentValues values = new ContentValues();
        values.put("ra", aluno.getRa());
        values.put("nome", aluno.getNome());
        values.put("disciplina", aluno.getDisciplina());
        values.put("bimestre1", aluno.getBimestre1());
        values.put("bimestre2", aluno.getBimestre2());
        values.put("bimestre3", aluno.getBimestre3());
        values.put("bimestre4", aluno.getBimestre4());
        values.put("media", aluno.getMedia());

        return database.insert("alunos", null, values);  // Insere no banco de dados e retorna o id do novo aluno
    }

    // Buscar todos os alunos no banco de dados
    @SuppressLint("Range")
    public ArrayList<Aluno> getAll() {
        ArrayList<Aluno> alunos = new ArrayList<>();
        Cursor cursor = database.query("alunos", null, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Aluno aluno = new Aluno();
                aluno.setRa(cursor.getString(cursor.getColumnIndex("ra")));
                aluno.setNome(cursor.getString(cursor.getColumnIndex("nome")));
                aluno.setDisciplina(cursor.getString(cursor.getColumnIndex("disciplina")));
                aluno.setBimestre1(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre1"))));
                aluno.setBimestre2(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre2"))));
                aluno.setBimestre3(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre3"))));
                aluno.setBimestre4(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre4"))));
                aluno.setMedia(cursor.getFloat(cursor.getColumnIndex("media")));

                alunos.add(aluno);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return alunos;
    }

    // Buscar alunos por disciplina
    @SuppressLint("Range")
    public ArrayList<Aluno> buscarAlunosPorDisciplina(String disciplina) {
        ArrayList<Aluno> alunos = new ArrayList<>();
        Cursor cursor = database.query("alunos", null, "disciplina = ?", new String[]{disciplina}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                Aluno aluno = new Aluno();
                aluno.setRa(cursor.getString(cursor.getColumnIndex("ra")));
                aluno.setNome(cursor.getString(cursor.getColumnIndex("nome")));
                aluno.setDisciplina(cursor.getString(cursor.getColumnIndex("disciplina")));
                aluno.setBimestre1(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre1"))));
                aluno.setBimestre2(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre2"))));
                aluno.setBimestre3(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre3"))));
                aluno.setBimestre4(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre4"))));
                aluno.setMedia(cursor.getFloat(cursor.getColumnIndex("media")));

                alunos.add(aluno);
            } while (cursor.moveToNext());

            cursor.close();
        }

        return alunos;
    }

    // Buscar um aluno por RA
    @SuppressLint("Range")
    public Aluno getById(int ra) {
        Aluno aluno = null;
        Cursor cursor = database.query("alunos", null, "ra = ?", new String[]{String.valueOf(ra)}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            aluno = new Aluno();
            aluno.setRa(cursor.getString(cursor.getColumnIndex("ra")));
            aluno.setNome(cursor.getString(cursor.getColumnIndex("nome")));
            aluno.setDisciplina(cursor.getString(cursor.getColumnIndex("disciplina")));
            aluno.setBimestre1(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre1"))));
            aluno.setBimestre2(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre2"))));
            aluno.setBimestre3(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre3"))));
            aluno.setBimestre4(String.valueOf(cursor.getFloat(cursor.getColumnIndex("bimestre4"))));
            aluno.setMedia(cursor.getFloat(cursor.getColumnIndex("media")));
            cursor.close();
        }

        return aluno;
    }

    // Atualizar a média de um aluno
    public int atualizarMediaAluno(String ra, float media) {
        ContentValues values = new ContentValues();
        values.put("media", media);

        return database.update("alunos", values, "ra = ?", new String[]{ra});
    }

    // Deletar um aluno pelo RA
    public void deletarAluno(String ra) {
        database.delete("alunos", "ra = ?", new String[]{ra});
    }
}
