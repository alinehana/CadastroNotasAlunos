package com.example.myapplication.view.controller;

import android.content.Context;
import android.text.TextUtils;

import com.example.myapplication.view.dao.AlunoDAO;
import com.example.myapplication.view.model.Aluno;

import java.util.ArrayList;

public class AlunoController {

    private Context context;

    public AlunoController(Context context) {
        this.context = context;
    }

    public String salvarAluno(String ra, String nome) {
        try {
            // Valida os campos estão preenchidos
            if (TextUtils.isEmpty(ra)) {
                return "Informe o RA do Aluno.";
            }
            if (TextUtils.isEmpty(nome)) {
                return "Informe o NOME do Aluno";
            }

            // Verifica se já existe o RA cadastrado
            AlunoDAO alunoDao = new AlunoDAO(context);
            Aluno aluno = alunoDao.getById(Integer.parseInt(ra));

            if (aluno != null) {
                return "O RA (" + ra + ") já está cadastrado.";
            } else {
                aluno = new Aluno();
                aluno.setRa(String.valueOf(Integer.parseInt(ra)));
                aluno.setNome(nome);

                long id = alunoDao.insert(aluno);

                if (id > 0) {
                    return "Dados do aluno gravados com sucesso.";
                } else {
                    return "Erro ao gravar dados do Aluno na BD.";
                }
            }

        } catch (Exception ex) {
            return "Erro ao Gravar dados do Aluno.";
        }

    }

    /**
     * Retorna todos os alunos cadastrados no banco
     * @return
     */
    public ArrayList<Aluno> retornarTodosAlunos() {
        AlunoDAO alunoDao = new AlunoDAO(context);
        return alunoDao.getAll();
    }
}
