package com.example.myapplication.view.helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteDataHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "escola.db";
    private static final int DATABASE_VERSION = 1;

    public SQLiteDataHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Criar tabela de alunos
        db.execSQL("CREATE TABLE alunos (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ra INTEGER NOT NULL, " +
                "nome TEXT NOT NULL" +
                ");");

        // Criar tabela de notas
        db.execSQL("CREATE TABLE notas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "ra_aluno INTEGER, " +
                "disciplina TEXT NOT NULL, " +
                "nota REAL, " +
                "bimestre INTEGER, " +
                "FOREIGN KEY (ra_aluno) REFERENCES alunos(ra)" +
                ");");

        // Inserir disciplinas padrão (não é necessário na sua implementação, pois o spinner já é dinâmico)
        ContentValues values = new ContentValues();
        values.put("nome", "Banco de Dados");
        db.insert("disciplinas", null, values);

        values.put("nome", "Programação");
        db.insert("disciplinas", null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS alunos");
        db.execSQL("DROP TABLE IF EXISTS notas");
        onCreate(db);
    }

    // Método para cadastrar uma nota
    public void cadastrarNota(String ra, String nome, String disciplina, String bimestre, float nota) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Verifica se o aluno já existe, caso não, insere
        ContentValues valuesAluno = new ContentValues();
        valuesAluno.put("ra", ra);
        valuesAluno.put("nome", nome);
        long alunoId = db.insertWithOnConflict("alunos", null, valuesAluno, SQLiteDatabase.CONFLICT_IGNORE);

        // Se o aluno foi inserido, insere a nota
        if (alunoId != -1) {
            ContentValues valuesNota = new ContentValues();
            valuesNota.put("ra_aluno", ra); // RA do aluno
            valuesNota.put("disciplina", disciplina); // Nome da disciplina
            valuesNota.put("nota", nota); // Valor da nota
            valuesNota.put("bimestre", bimestre); // Bimestre
            db.insert("notas", null, valuesNota);
        }

        db.close();
    }
}
